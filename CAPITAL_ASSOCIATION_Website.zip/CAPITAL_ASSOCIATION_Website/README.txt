CAPITAL ASSOCIATION — CONSTRUCTION WEBSITE STARTER
===============================================

FILES
- index.html: responsive website (HTML, CSS and JavaScript in one file)
- README.txt: this guide

HOW TO PREVIEW
1. Extract the ZIP file.
2. Double-click index.html to open it in Chrome, Edge or Firefox.
3. An internet connection is needed for the sample architectural photos.
4. Click “Edit website content” to change company details and package prices in this browser.
5. Use “Export content JSON” to back up the current data.

CONTACT DETAILS PRE-FILLED
Company: CAPITAL ASSOCIATION
Phone: 9841377439
Location: Chennai, Tamil Nadu
Logo: original gold CA architectural monogram with a house roofline

IMPORTANT BEFORE PUBLISHING
- Package prices are illustrative demo values, not an approved quote or rate card.
- The specification comparison is a planning template. Confirm exact brands, grades, sizes, quantities, warranties, inclusions and exclusions with the engineer and signed contract.
- Gallery photos are inspiration photos, not confirmed CAPITAL ASSOCIATION projects. Replace them with your own images.
- Testimonials are placeholders. Replace them with genuine customer-approved reviews or remove them.
- Add your full office street address, email, company details (if applicable), verified project photos and exact map pin.
- The editor saves changes only in the current browser. It is not a secure server-side CMS and will not sync between devices.
- For a public production website, upload to a hosting provider and connect a proper CMS/backend if you need secure login, shared editing, image uploads or lead storage.
